# Connectorthon-Template
#### Template for PPT and doc is available in "templates" folder.
#### Your connector package should be there in "connector" folder.
#### All documentation should be add to "Documentation" folder.
#### Anything and everything related to testing should be added in "Testing" folder.
